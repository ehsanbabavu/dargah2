(function () {
    if (!window.wc || !window.wc.wcBlocksRegistry) {
        return;
    }

    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { getSetting } = window.wc.wcSettings;
    const createElement = window.wp ? window.wp.element.createElement : null;

    const settings = getSetting('blupal_c2c_data', {});
    const defaultLabel = 'پرداخت کارت به کارت هوشمند (تایید آنی)';

    const label = settings.title || defaultLabel;
    const description = settings.description || 'انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.';

    const Content = function () {
        if (!createElement) return description;
        return createElement(
            'div',
            { className: 'wc-block-components-payment-method-description' },
            description
        );
    };

    const Label = function () {
        if (!createElement) return label;
        return createElement('span', null, label);
    };

    registerPaymentMethod({
        name: 'blupal_c2c',
        label: createElement ? createElement(Label, null) : label,
        content: createElement ? createElement(Content, null) : description,
        edit: createElement ? createElement(Content, null) : description,
        canMakePayment: function () {
            return true;
        },
        ariaLabel: label,
        supports: {
            features: settings.supports || ['products'],
        },
    });
})();
