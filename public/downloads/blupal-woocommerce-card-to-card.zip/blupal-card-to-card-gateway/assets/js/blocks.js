(function () {
    var isRegistered = false;

    function initBlupalBlocksGateway() {
        if (isRegistered) return true;

        var registry = (window.wc && window.wc.wcBlocksRegistry) || window.wcBlocksRegistry;
        var wcSettingsObj = (window.wc && window.wc.wcSettings) || window.wcSettings;
        var wpElem = (window.wp && window.wp.element) || (window.React ? { createElement: window.React.createElement } : null);

        if (!registry || !registry.registerPaymentMethod) {
            return false;
        }

        var settings = {};
        if (wcSettingsObj && typeof wcSettingsObj.getSetting === 'function') {
            settings = wcSettingsObj.getSetting('blupal_c2c_data', {});
        }
        if (!settings.title && window.blupalC2cConfig) {
            settings = window.blupalC2cConfig;
        }

        var titleText = settings.title || 'پرداخت کارت به کارت هوشمند (تایید آنی)';
        var descText = settings.description || 'انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.';
        var iconUrl = settings.icon || '';

        var createElem = (wpElem && wpElem.createElement) ? wpElem.createElement : function(tag, props, child) {
            return child;
        };

        var Content = function () {
            if (!wpElem || !wpElem.createElement) {
                return null;
            }
            return createElem(
                'div',
                { 
                    style: { 
                        padding: '10px 4px', 
                        fontSize: '13px', 
                        color: '#475569', 
                        lineHeight: '1.8' 
                    } 
                },
                descText
            );
        };

        var Label = function (props) {
            if (!wpElem || !wpElem.createElement) {
                return titleText;
            }
            var PaymentMethodLabel = props && props.components ? props.components.PaymentMethodLabel : null;
            if (PaymentMethodLabel) {
                return createElem(PaymentMethodLabel, { text: titleText });
            }
            return createElem('span', { style: { fontWeight: '600' } }, titleText);
        };

        try {
            registry.registerPaymentMethod({
                name: 'blupal_c2c',
                label: createElem(Label, null),
                content: createElem(Content, null),
                edit: createElem(Content, null),
                canMakePayment: function () { return true; },
                ariaLabel: titleText,
                supports: {
                    features: (settings && settings.supports) ? settings.supports : ['products'],
                },
            });
            isRegistered = true;
            return true;
        } catch (e) {
            console.warn('Blupal C2C Block registration error:', e);
            return false;
        }
    }

    // Attempt immediately
    if (!initBlupalBlocksGateway()) {
        // Polling retry loop up to 100 times (5 seconds)
        var attempts = 0;
        var intervalId = setInterval(function () {
            attempts++;
            if (initBlupalBlocksGateway() || attempts > 100) {
                clearInterval(intervalId);
            }
        }, 50);

        if (window.wp && window.wp.domReady) {
            window.wp.domReady(function() {
                initBlupalBlocksGateway();
            });
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                initBlupalBlocksGateway();
            });
        }
    }
})();
