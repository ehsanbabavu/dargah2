<?php
/**
 * Plugin Name: درگاه پرداخت کارت به کارت هوشمند (بلوپال)
 * Plugin URI: http://localhost:3000
 * Description: افزونه درگاه پرداخت کارت به کارت خودکار ووکامرس با تایید آنی شتاب، استعلام لحظه‌ای و پیگیری سفارشات.
 * Version: 1.1.0
 * Author: سامانه پرداخت کارت به کارت
 * Author URI: http://localhost:3000
 * Text Domain: wc-blupal-c2c
 * Domain Path: /languages
 * Requires at least: 5.4
 * Requires PHP: 7.2
 * WC requires at least: 4.0
 * WC tested up to: 9.2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Plugin Constants
define('BLUPAL_C2C_VERSION', '1.1.0');
define('BLUPAL_C2C_FILE', __FILE__);
define('BLUPAL_C2C_DIR', plugin_dir_path(__FILE__));
define('BLUPAL_C2C_URL', plugin_dir_url(__FILE__));
define('BLUPAL_C2C_DEFAULT_SERVER', 'http://localhost:3000');
define('BLUPAL_C2C_DEFAULT_API_KEY', '');

// Declare compatibility with WooCommerce HPOS (Custom Order Tables), Blocks, and New Product Editor
add_action('before_woocommerce_init', 'blupal_c2c_declare_compatibility');
function blupal_c2c_declare_compatibility() {
    if (class_exists('AutomatticWooCommerceUtilitiesFeaturesUtil')) {
        AutomatticWooCommerceUtilitiesFeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        AutomatticWooCommerceUtilitiesFeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        AutomatticWooCommerceUtilitiesFeaturesUtil::declare_compatibility('product_block_editor', __FILE__, true);
        AutomatticWooCommerceUtilitiesFeaturesUtil::declare_compatibility('analytics', __FILE__, true);
        AutomatticWooCommerceUtilitiesFeaturesUtil::declare_compatibility('order_attribution', __FILE__, true);
    }
}

// Ensure default settings are initialized so gateway is enabled out of the box
add_action('init', 'blupal_c2c_ensure_default_settings');
register_activation_hook(__FILE__, 'blupal_c2c_ensure_default_settings');
function blupal_c2c_ensure_default_settings() {
    $existing = get_option('woocommerce_blupal_c2c_settings');
    $default_server = defined('BLUPAL_C2C_DEFAULT_SERVER') ? BLUPAL_C2C_DEFAULT_SERVER : 'http://localhost:3000';
    $default_key = defined('BLUPAL_C2C_DEFAULT_API_KEY') ? BLUPAL_C2C_DEFAULT_API_KEY : '';

    if (empty($existing) || !is_array($existing)) {
        update_option('woocommerce_blupal_c2c_settings', array(
            'enabled'     => 'yes',
            'title'       => 'پرداخت کارت به کارت هوشمند (تایید آنی)',
            'description' => 'انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.',
            'server_url'  => $default_server,
            'api_key'     => $default_key,
        ));
    } else {
        $updated = false;
        if (!isset($existing['enabled']) || empty($existing['enabled'])) {
            $existing['enabled'] = 'yes';
            $updated = true;
        }
        if (empty($existing['server_url'])) {
            $existing['server_url'] = $default_server;
            $updated = true;
        }
        if ($updated) {
            update_option('woocommerce_blupal_c2c_settings', $existing);
        }
    }
}

// Bootstrap plugin components on plugins_loaded hook with priority 11 (after WooCommerce loads at 10)
add_action('plugins_loaded', 'blupal_c2c_init_plugin', 11);
function blupal_c2c_init_plugin() {
    if (!class_exists('WC_Payment_Gateway')) {
        add_action('admin_notices', 'blupal_c2c_missing_wc_notice');
        return;
    }

    blupal_c2c_load_classes();
}

/**
 * Load gateway classes safely
 */
function blupal_c2c_load_classes() {
    if (!class_exists('WC_Gateway_Blupal_C2C') && class_exists('WC_Payment_Gateway')) {
        require_once BLUPAL_C2C_DIR . 'includes/class-blupal-api.php';
        require_once BLUPAL_C2C_DIR . 'includes/class-blupal-webhook.php';
        require_once BLUPAL_C2C_DIR . 'includes/class-wc-gateway-blupal.php';
    }
}

/**
 * Register gateway class into WooCommerce globally
 */
add_filter('woocommerce_payment_gateways', 'blupal_c2c_register_gateway', 10);
function blupal_c2c_register_gateway($methods) {
    blupal_c2c_load_classes();
    if (!in_array('WC_Gateway_Blupal_C2C', $methods)) {
        $methods[] = 'WC_Gateway_Blupal_C2C';
    }
    return $methods;
}

/**
 * Ensure gateway is ALWAYS active in available payment gateways list if enabled
 */
add_filter('woocommerce_available_payment_gateways', 'blupal_c2c_ensure_available_in_checkout', 9999, 1);
function blupal_c2c_ensure_available_in_checkout($available_gateways) {
    if (isset($available_gateways['blupal_c2c'])) {
        return $available_gateways;
    }

    $settings = get_option('woocommerce_blupal_c2c_settings', array());
    $is_disabled = isset($settings['enabled']) && ($settings['enabled'] === 'no' || $settings['enabled'] === '0' || $settings['enabled'] === false);

    if (!$is_disabled) {
        blupal_c2c_load_classes();
        if (class_exists('WC_Gateway_Blupal_C2C')) {
            $gateways = WC()->payment_gateways->payment_gateways();
            if (isset($gateways['blupal_c2c'])) {
                $available_gateways['blupal_c2c'] = $gateways['blupal_c2c'];
            } else {
                $available_gateways['blupal_c2c'] = new WC_Gateway_Blupal_C2C();
            }
        }
    }

    return $available_gateways;
}

/**
 * Register WooCommerce Blocks Checkout support for both classic and block checkouts
 */
add_action('woocommerce_blocks_loaded', 'blupal_c2c_register_blocks_support');
function blupal_c2c_register_blocks_support() {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }

    require_once BLUPAL_C2C_DIR . 'includes/class-blupal-blocks-support.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        'blupal_c2c_blocks_handler'
    );
}

// Also hook directly to payment method type registration for modern WC 8+ / 9+
add_action('woocommerce_blocks_payment_method_type_registration', 'blupal_c2c_blocks_handler');
function blupal_c2c_blocks_handler($payment_method_registry) {
    static $registered = false;
    if ($registered) {
        return;
    }

    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        require_once BLUPAL_C2C_DIR . 'includes/class-blupal-blocks-support.php';
        if (class_exists('WC_Blupal_Blocks_Support') && is_object($payment_method_registry) && method_exists($payment_method_registry, 'register')) {
            $payment_method_registry->register(new WC_Blupal_Blocks_Support());
            $registered = true;
        }
    }
}

/**
 * Enqueue frontend block assets on checkout and cart pages as additional guarantee
 */
add_action('wp_enqueue_scripts', 'blupal_c2c_enqueue_frontend_scripts');
function blupal_c2c_enqueue_frontend_scripts() {
    if (function_exists('is_checkout') && is_checkout()) {
        wp_enqueue_script(
            'blupal-c2c-blocks-integration',
            BLUPAL_C2C_URL . 'assets/js/blocks.js',
            array('jquery'),
            BLUPAL_C2C_VERSION,
            true
        );

        $settings = get_option('woocommerce_blupal_c2c_settings', array());
        $title = !empty($settings['title']) ? $settings['title'] : 'پرداخت کارت به کارت هوشمند (تایید آنی)';
        $description = !empty($settings['description']) ? $settings['description'] : 'انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.';

        wp_localize_script('blupal-c2c-blocks-integration', 'blupalC2cConfig', array(
            'title'       => $title,
            'description' => $description,
            'icon'        => BLUPAL_C2C_URL . 'assets/images/icon.svg',
            'enabled'     => (!isset($settings['enabled']) || $settings['enabled'] !== 'no'),
        ));
    }
}

/**
 * Notice if WooCommerce is not active
 */
function blupal_c2c_missing_wc_notice() {
    ?>
    <div class="notice notice-error is-dismissible">
        <p><strong><?php esc_html_e('درگاه پرداخت کارت به کارت هوشمند:', 'wc-blupal-c2c'); ?></strong> <?php esc_html_e('برای استفاده از این درگاه، افزونه ووکامرس (WooCommerce) باید نصب و فعال باشد.', 'wc-blupal-c2c'); ?></p>
    </div>
    <?php
}

/**
 * Add settings shortcut link to WordPress Plugins page
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'blupal_c2c_settings_action_link');
function blupal_c2c_settings_action_link($links) {
    $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=blupal_c2c');
    $action_links = array(
        'settings' => '<a href="' . esc_url($settings_url) . '">' . esc_html__('پیکربندی درگاه', 'wc-blupal-c2c') . '</a>',
    );
    return array_merge($action_links, $links);
}

/**
 * Global AJAX handler for live connection test from settings page
 * Hooked at root level so admin-ajax.php always recognizes this action
 */
add_action('wp_ajax_blupal_c2c_test_connection', 'blupal_c2c_ajax_test_connection_callback');
function blupal_c2c_ajax_test_connection_callback() {
    // Check nonce or admin capabilities
    $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
    if (!wp_verify_nonce($nonce, 'blupal_c2c_test_nonce')) {
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            wp_send_json_error(array(
                'status'  => 'nonce_failed',
                'message' => 'اعتبار نشست کاری به پایان رسیده است. لطفاً صفحه را رفرش فرمایید.',
            ));
            exit;
        }
    }

    if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
        wp_send_json_error(array(
            'status'  => 'unauthorized',
            'message' => 'دسترسی غیرمجاز. فقط مدیران فروشگاه امکان بررسی اتصال را دارند.',
        ));
        exit;
    }

    blupal_c2c_load_classes();

    if (!class_exists('Blupal_C2C_API')) {
        require_once BLUPAL_C2C_DIR . 'includes/class-blupal-api.php';
    }

    $server_url = isset($_POST['server_url']) ? esc_url_raw(trim($_POST['server_url'])) : '';
    $api_key    = isset($_POST['api_key']) ? sanitize_text_field(trim($_POST['api_key'])) : '';

    if (empty($server_url)) {
        $settings = get_option('woocommerce_blupal_c2c_settings', array());
        $server_url = !empty($settings['server_url']) ? $settings['server_url'] : BLUPAL_C2C_DEFAULT_SERVER;
    }

    if (empty($api_key)) {
        $settings = get_option('woocommerce_blupal_c2c_settings', array());
        $api_key = !empty($settings['api_key']) ? $settings['api_key'] : BLUPAL_C2C_DEFAULT_API_KEY;
    }

    if (empty($server_url)) {
        wp_send_json_error(array(
            'status'  => 'missing_server_url',
            'message' => 'لطفاً ابتدا آدرس سرور (API Base URL) را در کادر تنظیمات وارد نمایید.',
        ));
        exit;
    }

    if (empty($api_key)) {
        wp_send_json_error(array(
            'status'  => 'missing_api_key',
            'message' => 'لطفاً ابتدا کلید اختصاصی اتصال (API Key) را در کادر تنظیمات وارد نمایید.',
        ));
        exit;
    }

    $test_api = new Blupal_C2C_API($server_url, $api_key);
    $result   = $test_api->test_connection();

    if (isset($result['success']) && $result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
    exit;
}
