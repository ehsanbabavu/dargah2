<?php
/**
 * Plugin Name: درگاه پرداخت کارت به کارت هوشمند (بلوپال)
 * Plugin URI: https://example.com
 * Description: افزونه درگاه پرداخت کارت به کارت خودکار ووکامرس با تایید آنی شتاب، استعلام لحظه‌ای و پیگیری سفارشات.
 * Version: 1.1.0
 * Author: سامانه پرداخت کارت به کارت
 * Author URI: https://example.com
 * Text Domain: wc-blupal-c2c
 * Domain Path: /languages
 * Requires at least: 5.4
 * Requires PHP: 7.2
 * WC requires at least: 4.0
 * WC tested up to: 9.2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Plugin Constants
define('BLUPAL_C2C_VERSION', '1.1.0');
define('BLUPAL_C2C_FILE', __FILE__);
define('BLUPAL_C2C_DIR', plugin_dir_path(__FILE__));
define('BLUPAL_C2C_URL', plugin_dir_url(__FILE__));
define('BLUPAL_C2C_DEFAULT_SERVER', 'https://example.com');
define('BLUPAL_C2C_DEFAULT_API_KEY', '');

// Declare compatibility with WooCommerce HPOS (Custom Order Tables) and Blocks
add_action('before_woocommerce_init', 'blupal_c2c_declare_compatibility');
function blupal_c2c_declare_compatibility() {
    if (!class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        return;
    }

    $features = array(
        'custom_order_tables',   // HPOS
        'cart_checkout_blocks',  // Checkout Blocks
        'analytics',
        'order_attribution',
    );

    foreach ($features as $feature_id) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            $feature_id,
            __FILE__,
            true
        );
    }
}

/**
 * Check if WooCommerce is active
 */
function blupal_c2c_check_woocommerce() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'blupal_c2c_missing_wc_notice');
        return false;
    }
    return true;
}

function blupal_c2c_missing_wc_notice() {
    echo '<div class="error"><p><strong>' . esc_html__('درگاه پرداخت کارت به کارت هوشمند:', 'wc-blupal-c2c') . '</strong> ' . esc_html__('برای استفاده از این درگاه، افزونه ووکامرس (WooCommerce) باید نصب و فعال باشد.', 'wc-blupal-c2c') . '</p></div>';
}

/**
 * Load plugin class files
 */
function blupal_c2c_load_classes() {
    if (!class_exists('Blupal_C2C_API')) {
        require_once BLUPAL_C2C_DIR . 'includes/class-blupal-api.php';
    }
    if (!class_exists('Blupal_C2C_Webhook')) {
        require_once BLUPAL_C2C_DIR . 'includes/class-blupal-webhook.php';
    }
    if (!class_exists('WC_Gateway_Blupal_C2C')) {
        require_once BLUPAL_C2C_DIR . 'includes/class-wc-gateway-blupal.php';
    }
}

/**
 * Register Gateway Class with WooCommerce
 */
add_filter('woocommerce_payment_gateways', 'blupal_c2c_add_gateway_class');
function blupal_c2c_add_gateway_class($gateways) {
    if (blupal_c2c_check_woocommerce()) {
        blupal_c2c_load_classes();
        $gateways[] = 'WC_Gateway_Blupal_C2C';
    }
    return $gateways;
}

/**
 * Ensure gateway is ALWAYS active in available payment gateways list if enabled
 */
add_filter('woocommerce_available_payment_gateways', 'blupal_c2c_ensure_available_in_checkout', 9999, 1);
function blupal_c2c_ensure_available_in_checkout($available_gateways) {
    if (isset($available_gateways['blupal_c2c'])) {
        return $available_gateways;
    }

    $settings = get_option('woocommerce_blupal_c2c_settings', array());
    $is_disabled = isset($settings['enabled']) && ($settings['enabled'] === 'no' || $settings['enabled'] === '0' || $settings['enabled'] === false);

    if (!$is_disabled) {
        blupal_c2c_load_classes();
        if (class_exists('WC_Gateway_Blupal_C2C')) {
            $gateways = WC()->payment_gateways->payment_gateways();
            if (isset($gateways['blupal_c2c'])) {
                $available_gateways['blupal_c2c'] = $gateways['blupal_c2c'];
            } else {
                $available_gateways['blupal_c2c'] = new WC_Gateway_Blupal_C2C();
            }
        }
    }

    return $available_gateways;
}

/**
 * Register WooCommerce Blocks Checkout support for both classic and block checkouts
 */
add_action('woocommerce_blocks_loaded', 'blupal_c2c_register_blocks_support');
function blupal_c2c_register_blocks_support() {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }

    require_once BLUPAL_C2C_DIR . 'includes/class-blupal-blocks-support.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        'blupal_c2c_blocks_handler'
    );
}

// Also hook directly to payment method type registration for modern WC 8+ / 9+
add_action('woocommerce_blocks_payment_method_type_registration', 'blupal_c2c_blocks_handler');
function blupal_c2c_blocks_handler($payment_method_registry) {
    static $registered = false;
    if ($registered) return;
    $registered = true;

    if (class_exists('WC_Blupal_Blocks_Support')) {
        $payment_method_registry->register(new WC_Blupal_Blocks_Support());
    }
}

/**
 * Add Plugin Action Links (Settings button on Plugins page)
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'blupal_c2c_action_links');
function blupal_c2c_action_links($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=blupal_c2c')) . '">' . esc_html__('پیکربندی درگاه', 'wc-blupal-c2c') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * Admin assets (enqueue CSS/JS for gateway settings)
 */
add_action('admin_enqueue_scripts', 'blupal_c2c_admin_assets');
function blupal_c2c_admin_assets($hook) {
    if (isset($_GET['page']) && $_GET['page'] === 'wc-settings' && isset($_GET['section']) && $_GET['section'] === 'blupal_c2c') {
        wp_enqueue_style(
            'blupal-c2c-admin-css',
            BLUPAL_C2C_URL . 'assets/css/admin.css',
            array(),
            BLUPAL_C2C_VERSION
        );
    }
}

/**
 * Global AJAX listener for live connection test from settings page
 */
add_action('wp_ajax_blupal_c2c_test_connection', 'blupal_c2c_ajax_test_connection_callback');
function blupal_c2c_ajax_test_connection_callback() {
    // Check nonce or admin capabilities
    $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
    if (!wp_verify_nonce($nonce, 'blupal_c2c_test_nonce')) {
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            wp_send_json_error(array(
                'status'  => 'nonce_failed',
                'message' => 'اعتبار نشست کاری به پایان رسیده است. لطفاً صفحه را رفرش فرمایید.',
            ));
            exit;
        }
    }

    if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
        wp_send_json_error(array(
            'status'  => 'unauthorized',
            'message' => 'دسترسی غیرمجاز. فقط مدیران فروشگاه امکان بررسی اتصال را دارند.',
        ));
        exit;
    }

    $server_url = isset($_POST['server_url']) ? esc_url_raw(trim($_POST['server_url'])) : '';
    $api_key    = isset($_POST['api_key']) ? sanitize_text_field(trim($_POST['api_key'])) : '';

    if (empty($server_url)) {
        wp_send_json_error(array(
            'status'  => 'missing_url',
            'message' => 'لطفاً ابتدا آدرس سرور (API Base URL) را در کادر تنظیمات وارد نمایید.',
        ));
        exit;
    }

    if (empty($api_key)) {
        wp_send_json_error(array(
            'status'  => 'missing_key',
            'message' => 'لطفاً ابتدا کلید اختصاصی اتصال (API Key) را در کادر تنظیمات وارد نمایید.',
        ));
        exit;
    }

    blupal_c2c_load_classes();
    if (class_exists('Blupal_C2C_API')) {
        $api = new Blupal_C2C_API($server_url, $api_key);
        $result = $api->test_connection();
        if (isset($result['success']) && $result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    } else {
        wp_send_json_error(array(
            'status'  => 'class_missing',
            'message' => 'کلاس API درگاه بارگذاری نشد.',
        ));
    }
    exit;
}
