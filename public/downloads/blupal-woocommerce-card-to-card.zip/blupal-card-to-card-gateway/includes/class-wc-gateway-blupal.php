<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once dirname(__FILE__) . '/class-blupal-api.php';
require_once dirname(__FILE__) . '/class-blupal-webhook.php';

if (!class_exists('WC_Gateway_Blupal_C2C') && class_exists('WC_Payment_Gateway')) {
    class WC_Gateway_Blupal_C2C extends WC_Payment_Gateway {
        public $api_key;
        public $server_url;
        private $api;

        public function __construct() {
            $this->id                 = 'blupal_c2c';
            $this->icon               = apply_filters('woocommerce_blupal_c2c_icon', BLUPAL_C2C_URL . 'assets/images/icon.svg');
            $this->has_fields         = false;
            $this->supports           = array('products');
            $this->method_title       = __('پرداخت کارت به کارت هوشمند', 'wc-blupal-c2c');
            $this->method_description = __('پرداخت مستقیم به شماره کارت پذیرنده با استعلام خودکار و آنی واریزی از طریق سامانه شتاب.', 'wc-blupal-c2c');

            // Initialize form fields and settings
            $this->init_form_fields();
            $this->init_settings();

            // Options
            $this->enabled     = $this->get_option('enabled', 'yes');
            $this->title       = $this->get_option('title', __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'));
            $this->description = $this->get_option('description', __('جهت پرداخت، اطلاعات سفارش به صفحه پرداخت امن هدایت شده و پس از انتقال کارت به کارت، سفارش شما به صورت آنی تایید می‌گردد.', 'wc-blupal-c2c'));
            $this->server_url  = rtrim($this->get_option('server_url', defined('BLUPAL_C2C_DEFAULT_SERVER') ? BLUPAL_C2C_DEFAULT_SERVER : 'https://example.com'), '/');
            $this->api_key     = trim($this->get_option('api_key', defined('BLUPAL_C2C_DEFAULT_API_KEY') ? BLUPAL_C2C_DEFAULT_API_KEY : ''));

            // Fallback for server url if left empty
            if (empty($this->server_url)) {
                $this->server_url = 'https://example.com';
            }

            // Initialize API Client
            $this->api = new Blupal_C2C_API($this->server_url, $this->api_key);

            // Hook into admin save
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            // Webhook and Callback listener: /?wc-api=wc_blupal_c2c
            add_action('woocommerce_api_wc_blupal_c2c', array($this, 'handle_callback'));

            // Enqueue admin assets on our settings page
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        }

        /**
         * Enqueue admin stylesheets
         */
        public function enqueue_admin_assets() {
            if (isset($_GET['section']) && $_GET['section'] === $this->id) {
                wp_enqueue_style(
                    'blupal-c2c-admin',
                    BLUPAL_C2C_URL . 'assets/css/admin.css',
                    array(),
                    BLUPAL_C2C_VERSION
                );
            }
        }

        /**
         * Admin settings form fields
         */
        public function init_form_fields() {
            $site_host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field($_SERVER['HTTP_HOST']) : '';
            $clean_host = preg_replace('/^www\./i', '', $site_host);

            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('فعال‌سازی درگاه', 'wc-blupal-c2c'),
                    'type'    => 'checkbox',
                    'label'   => __('فعال‌سازی پرداخت کارت به کارت هوشمند در برگه تسویه حساب', 'wc-blupal-c2c'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __('عنوان درگاه در برگه تسویه حساب', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => __('عنوانی که خریدار در مرحله پرداخت مشاهده می‌کند.', 'wc-blupal-c2c'),
                    'default'     => __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'),
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => __('توضیحات درگاه برای مشتری', 'wc-blupal-c2c'),
                    'type'        => 'textarea',
                    'description' => __('توضیحاتی که پس از انتخاب این گزینه در صفحه پرداخت نمایش داده می‌شود.', 'wc-blupal-c2c'),
                    'default'     => __('انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.', 'wc-blupal-c2c'),
                ),
                'server_url' => array(
                    'title'       => __('آدرس وب‌سرویس / سرور پرداخت (API Base URL)', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => sprintf(
                        __('آدرس سرور یا دامنه سامانه پرداخت بلوپال بدون اسلش پایانی. پیش‌فرض: <strong dir="ltr">%s</strong>', 'wc-blupal-c2c'),
                        esc_html('https://example.com')
                    ),
                    'default'     => defined('BLUPAL_C2C_DEFAULT_SERVER') ? BLUPAL_C2C_DEFAULT_SERVER : 'https://example.com',
                    'placeholder' => 'https://example.com',
                ),
                'api_key' => array(
                    'title'       => __('کلید اختصاصی اتصال (API Key)', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => sprintf(
                        __('کلید وب‌سرویس اختصاصی صادر شده در پنل کاربری شما. دامنه این سایت: <strong dir="ltr">%s</strong> (حتماً در پنل درگاه ثبت شود).', 'wc-blupal-c2c'),
                        esc_html($clean_host)
                    ),
                    'default'     => defined('BLUPAL_C2C_DEFAULT_API_KEY') ? BLUPAL_C2C_DEFAULT_API_KEY : '',
                    'placeholder' => 'Rakhsh_Pay_...',
                ),
            );
        }

        /**
         * Render admin options page with Live Test Connection Tool and Modern UI
         */
        public function admin_options() {
            $site_host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field($_SERVER['HTTP_HOST']) : '';
            $clean_host = preg_replace('/^www\./i', '', $site_host);
            $test_nonce = wp_create_nonce('blupal_c2c_test_nonce');
            $webhook_url = add_query_arg(array('wc-api' => 'wc_blupal_c2c'), home_url('/'));
            ?>
            <div class="blupal-admin-wrapper" dir="rtl">
                <!-- Header Hero Banner -->
                <div class="blupal-admin-hero">
                    <div class="blupal-hero-top">
                        <div class="blupal-hero-brand">
                            <div class="blupal-logo-icon">
                                ⚡
                            </div>
                            <div>
                                <div class="blupal-hero-title-row">
                                    <h2 class="blupal-hero-title">درگاه پرداخت کارت به کارت هوشمند بلوپال</h2>
                                    <span class="blupal-version-pill">نسخه <?php echo esc_html(BLUPAL_C2C_VERSION); ?></span>
                                    <span class="blupal-status-online"><span class="blupal-pulse-dot"></span> فعال و آماده اتصال</span>
                                </div>
                                <p class="blupal-hero-subtitle">پیکربندی درگاه پرداخت کارت به کارت خودکار ووکامرس، تایید آنی شتابی و مدیریت اتصال آنلاین</p>
                            </div>
                        </div>
                    </div>

                    <div class="blupal-hero-chips">
                        <div class="blupal-chip-item">
                            <span class="blupal-chip-label">🌐 دامنه مجاز درگاه:</span>
                            <code class="blupal-chip-code" dir="ltr"><?php echo esc_html($clean_host); ?></code>
                            <button type="button" class="blupal-chip-copy" onclick="navigator.clipboard.writeText('<?php echo esc_js($clean_host); ?>'); alert('دامنه مجاز کپی شد!');">کپی</button>
                        </div>
                        <div class="blupal-chip-item">
                            <span class="blupal-chip-label">🔗 وب‌هوک بازگشتی:</span>
                            <code class="blupal-chip-code" dir="ltr"><?php echo esc_html($webhook_url); ?></code>
                            <button type="button" class="blupal-chip-copy" onclick="navigator.clipboard.writeText('<?php echo esc_js($webhook_url); ?>'); alert('آدرس وب‌هوک کپی شد!');">کپی</button>
                        </div>
                    </div>
                </div>

                <!-- Live Test Connection Box -->
                <div class="blupal-card blupal-tester-card">
                    <div class="blupal-card-header">
                        <div class="blupal-card-title-group">
                            <div class="blupal-icon-badge blue">⚡</div>
                            <div>
                                <h3 class="blupal-card-title">ابزار تست زنده اتصال و عیب‌یابی وب‌سرویس</h3>
                                <p class="blupal-card-desc">بررسی آنی ارتباط با سرور، صحت کلید API و دریافت اطلاعات کارت فعال پذیرنده</p>
                            </div>
                        </div>
                        <button type="button" id="blupal-btn-test-connection" class="blupal-btn-primary">
                            <span class="blupal-btn-text">بررسی و تست اتصال به سرور</span>
                            <span class="blupal-spinner" style="display: none;"></span>
                        </button>
                    </div>

                    <div id="blupal-test-result" class="blupal-test-result" style="display: none;"></div>
                </div>

                <!-- Setup Steps Guide -->
                <div class="blupal-card blupal-guide-card">
                    <div class="blupal-guide-grid">
                        <div class="blupal-guide-step">
                            <div class="blupal-step-num">۱</div>
                            <div class="blupal-step-content">
                                <strong>کپی کلید API اختصاصی</strong>
                                <p>کلید صادر شده در پنل مدیریت بلوپال را در فیلد پایین وارد نمایید.</p>
                            </div>
                        </div>
                        <div class="blupal-guide-step">
                            <div class="blupal-step-num">۲</div>
                            <div class="blupal-step-content">
                                <strong>ثبت دامنه <code dir="ltr"><?php echo esc_html($clean_host); ?></code></strong>
                                <p>در پنل کاربری بلوپال، دامنه مجاز درگاه را دقیقا با این دامنه مطابقت دهید.</p>
                            </div>
                        </div>
                        <div class="blupal-guide-step">
                            <div class="blupal-step-num">۳</div>
                            <div class="blupal-step-content">
                                <strong>تایید آنی و بدون نیاز به کارت</strong>
                                <p>شماره کارت به صورت خودکار از سرور دریافت و به خریدار نمایش داده می‌شود.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- WooCommerce Gateway Settings Box -->
                <div class="blupal-card blupal-settings-card">
                    <div class="blupal-settings-card-header">
                        <div class="blupal-card-title-group">
                            <div class="blupal-icon-badge indigo">⚙️</div>
                            <div>
                                <h3 class="blupal-card-title">تنظیمات اصلی درگاه پرداخت</h3>
                                <p class="blupal-card-desc">اطلاعات نمایش داده شده به خریداران در برگه تسویه حساب و مشخصات کلید وب‌سرویس</p>
                            </div>
                        </div>
                    </div>

                    <div class="blupal-settings-form-wrapper">
                        <table class="form-table blupal-custom-table">
                            <?php $this->generate_settings_html(); ?>
                        </table>
                    </div>
                </div>
            </div>

            <script type="text/javascript">
            (function($) {
                $(document).ready(function() {
                    function renderSuccessResult(data, $resultBox) {
                        var details = data.details || {};
                        var latency = data.latency_ms ? data.latency_ms + ' میلی‌ثانیه' : 'آنی';

                        var html = '<div class="blupal-alert blupal-alert-success">';
                        html += '<div class="blupal-alert-head">✅ <strong>اتصال به سرور کاملاً برقرار و تایید شد!</strong> <span class="blupal-latency">پینگ سرور: ' + latency + '</span></div>';
                        html += '<p class="blupal-alert-msg">' + (data.message || 'ارتباط با سرور پرداخت با موفقیت برقرار شد.') + '</p>';

                        html += '<div class="blupal-details-grid">';
                        if (details.gateway_title) {
                            html += '<div class="blupal-grid-item"><span>نام درگاه در سامانه:</span> <strong>' + details.gateway_title + '</strong></div>';
                        }
                        if (details.card_holder) {
                            html += '<div class="blupal-grid-item"><span>وضعیت کارت پذیرنده:</span> <strong style="color:#059669;">' + details.card_holder + '</strong></div>';
                        }
                        if (details.authorized_domain) {
                            html += '<div class="blupal-grid-item"><span>دامنه مجاز درگاه:</span> <code dir="ltr">' + details.authorized_domain + '</code></div>';
                        }
                        if (details.server_url) {
                            html += '<div class="blupal-grid-item"><span>آدرس سرور پاسخ‌دهنده:</span> <code dir="ltr">' + details.server_url + '</code></div>';
                        }
                        html += '</div>';
                        html += '</div>';

                        $resultBox.html(html).slideDown(200);
                    }

                    function renderErrorResult(err, $resultBox, note) {
                        var errMsg = (err && err.message) ? err.message : 'عدم امکان برقراری ارتباط با وب‌سرویس.';
                        var latency = (err && err.latency_ms) ? ' (زمان پاسخ: ' + err.latency_ms + 'ms)' : '';

                        var html = '<div class="blupal-alert blupal-alert-error">';
                        html += '<div class="blupal-alert-head">❌ <strong>خطا در بررسی ارتباط:</strong> ' + latency + '</div>';
                        html += '<p class="blupal-alert-msg">' + errMsg + '</p>';
                        if (note) {
                            html += '<div class="blupal-troubleshoot-hint">💡 ' + note + '</div>';
                        } else {
                            html += '<div class="blupal-troubleshoot-hint">💡 <strong>راهنما:</strong> لطفاً آدرس سرور و کلید API را مجدداً بررسی کنید و در پایین صفحه روی «ذخیره تغییرات» کلیک نمایید.</div>';
                        }
                        html += '</div>';

                        $resultBox.html(html).slideDown(200);
                    }

                    $('#blupal-btn-test-connection').on('click', function(e) {
                        e.preventDefault();
                        var $btn = $(this);
                        var $spinner = $btn.find('.blupal-spinner');
                        var $btnText = $btn.find('.blupal-btn-text');
                        var $resultBox = $('#blupal-test-result');

                        var serverUrl = ($('#woocommerce_blupal_c2c_server_url').val() || '<?php echo esc_js($this->server_url); ?>').trim().replace(//+$/, '');
                        var apiKey = ($('#woocommerce_blupal_c2c_api_key').val() || '<?php echo esc_js($this->api_key); ?>').trim();
                        var ajaxUrl = (typeof ajaxurl !== 'undefined') ? ajaxurl : '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';

                        if (!serverUrl) {
                            renderErrorResult({ message: 'لطفاً ابتدا آدرس سرور (API Base URL) را در کادر تنظیمات زیر وارد نمایید.' }, $resultBox);
                            return;
                        }

                        $btn.prop('disabled', true);
                        $spinner.show();
                        $btnText.text('در حال برقراری ارتباط با سرور...');
                        $resultBox.slideUp(150);

                        // 1. First attempt: Standard WordPress backend AJAX
                        $.ajax({
                            url: ajaxUrl,
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                action: 'blupal_c2c_test_connection',
                                security: '<?php echo esc_js($test_nonce); ?>',
                                server_url: serverUrl,
                                api_key: apiKey
                            },
                            success: function(response) {
                                $btn.prop('disabled', false);
                                $spinner.hide();
                                $btnText.text('بررسی مجدد اتصال به سرور');

                                if (response && response.success && response.data) {
                                    renderSuccessResult(response.data, $resultBox);
                                } else {
                                    var err = (response && response.data) ? response.data : { message: 'پاسخ ناموفق از سرور' };
                                    renderErrorResult(err, $resultBox);
                                }
                            },
                            error: function(xhr, status, error) {
                                // 2. Fallback: Direct browser fetch to server test endpoint if WP AJAX had issue
                                var directEndpoint = serverUrl + '/api/v1/woocommerce/test-connection';
                                var startTime = Date.now();

                                fetch(directEndpoint, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json',
                                        'X-WP-API-KEY': apiKey
                                    },
                                    body: JSON.stringify({
                                        api_key: apiKey,
                                        site_url: window.location.origin,
                                        domain: window.location.hostname
                                    })
                                })
                                .then(function(res) { return res.json(); })
                                .then(function(directData) {
                                    $btn.prop('disabled', false);
                                    $spinner.hide();
                                    $btnText.text('بررسی مجدد اتصال به سرور');
                                    directData.latency_ms = Date.now() - startTime;

                                    if (directData && directData.success) {
                                        renderSuccessResult(directData, $resultBox);
                                    } else {
                                        renderErrorResult(directData, $resultBox);
                                    }
                                })
                                .catch(function(fetchErr) {
                                    $btn.prop('disabled', false);
                                    $spinner.hide();
                                    $btnText.text('تلاش مجدد برای تست اتصال');

                                    var detailedMsg = 'عدم دسترسی به سرور پرداخت. لطفا مطمئن شوید آدرس سرور به صورت کامل و با پیشوند https:// وارد شده است.';
                                    if (xhr && xhr.status === 403) {
                                        detailedMsg = 'دسترسی غیرمجاز وردپرس (کد ۴۰۳). لطفاً صفحه را رفرش فرمایید.';
                                    }
                                    renderErrorResult({ message: detailedMsg }, $resultBox, 'آدرس سرور جاری: <code>' + serverUrl + '</code>');
                                });
                            }
                        });
                    });
                });
            })(jQuery);
            </script>
            <?php
        }

        /**
         * Process payment and redirect customer to payment page
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                wc_add_notice(__('سفارش مورد نظر یافت نشد.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            if (empty($this->api_key)) {
                wc_add_notice(__('کلید درگاه کارت به کارت در تنظیمات ووکامرس پیکربندی نشده است.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            // Convert currency to Tomans
            $currency = get_woocommerce_currency();
            $order_total = floatval($order->get_total());
            $amount_in_tomans = $order_total;
            $curr_upper = strtoupper(trim($currency));

            if (in_array($curr_upper, array('IRR', 'RIAL', 'RIALS', 'IR_RIAL', 'IRR_CURRENCY'))) {
                $amount_in_tomans = $order_total / 10;
            } elseif (in_array($curr_upper, array('IRHR', 'THOUSAND_TOMAN', 'HEZAR_TOMAN'))) {
                $amount_in_tomans = $order_total * 1000;
            }

            $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            if (empty($customer_name)) {
                $customer_name = 'مشتری سفارش #' . $order_id;
            }

            $customer_data = array(
                'name'  => $customer_name,
                'phone' => $order->get_billing_phone(),
                'email' => $order->get_billing_email(),
            );

            $callback_url = add_query_arg(array('wc-api' => 'wc_blupal_c2c', 'order_id' => $order_id), home_url('/'));

            // Call API
            $result = $this->api->create_order($order_id, $amount_in_tomans, $currency, $customer_data, $callback_url);

            if (!$result || !isset($result['success']) || !$result['success']) {
                $msg = isset($result['message']) ? $result['message'] : __('خطا در صدور فاکتور پرداخت.', 'wc-blupal-c2c');
                wc_add_notice($msg, 'error');
                return array('result' => 'failure');
            }

            // Save invoice id into order meta
            if (!empty($result['invoice_id'])) {
                $order->update_meta_data('_blupal_c2c_invoice_id', sanitize_text_field($result['invoice_id']));
                $order->save();
            }

            // اطمینان از دریافت آدرس معتبر صفحه پرداخت پیش از ریدایرکت مشتری.
            if (empty($result['payment_url']) || !filter_var($result['payment_url'], FILTER_VALIDATE_URL)) {
                wc_add_notice(__('آدرس صفحه پرداخت از سرور دریافت نشد. لطفاً مجدداً تلاش فرمایید.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            // Redirect customer to secure payment page
            return array(
                'result'   => 'success',
                'redirect' => $result['payment_url'],
            );
        }

        /**
         * Check if payment gateway is available at checkout
         */
        public function is_available() {
            if ('yes' !== $this->enabled) {
                return false;
            }

            return parent::is_available();
        }

        /**
         * Handle return callback and webhook
         */
        public function handle_callback() {
            Blupal_C2C_Webhook::handle($this, $this->api);
        }
    }
}
