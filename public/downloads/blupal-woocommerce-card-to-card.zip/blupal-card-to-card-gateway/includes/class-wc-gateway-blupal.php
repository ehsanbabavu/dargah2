<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once dirname(__FILE__) . '/class-blupal-api.php';
require_once dirname(__FILE__) . '/class-blupal-webhook.php';

if (!class_exists('WC_Gateway_Blupal_C2C') && class_exists('WC_Payment_Gateway')) {
    class WC_Gateway_Blupal_C2C extends WC_Payment_Gateway {
        public $api_key;
        public $server_url;
        private $api;

        public function __construct() {
            $this->id                 = 'blupal_c2c';
            $this->icon               = apply_filters('woocommerce_blupal_c2c_icon', BLUPAL_C2C_URL . 'assets/images/icon.svg');
            $this->has_fields         = false;
            $this->supports           = array('products');
            $this->method_title       = __('پرداخت کارت به کارت هوشمند', 'wc-blupal-c2c');
            $this->method_description = __('پرداخت مستقیم به شماره کارت پذیرنده با استعلام خودکار و آنی واریزی از طریق سامانه شتاب.', 'wc-blupal-c2c');

            // Initialize form fields and settings
            $this->init_form_fields();
            $this->init_settings();

            // Options
            $this->enabled     = $this->get_option('enabled', 'yes');
            $this->title       = $this->get_option('title', __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'));
            $this->description = $this->get_option('description', __('جهت پرداخت، اطلاعات سفارش به صفحه پرداخت امن هدایت شده و پس از انتقال کارت به کارت، سفارش شما به صورت آنی تایید می‌گردد.', 'wc-blupal-c2c'));
            $this->server_url  = rtrim($this->get_option('server_url', defined('BLUPAL_C2C_DEFAULT_SERVER') ? BLUPAL_C2C_DEFAULT_SERVER : 'http://localhost:3000'), '/');
            $this->api_key     = trim($this->get_option('api_key', defined('BLUPAL_C2C_DEFAULT_API_KEY') ? BLUPAL_C2C_DEFAULT_API_KEY : ''));

            // Fallback for server url if left empty
            if (empty($this->server_url)) {
                $this->server_url = 'http://localhost:3000';
            }

            // Initialize API Client
            $this->api = new Blupal_C2C_API($this->server_url, $this->api_key);

            // Hook into admin save
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            // AJAX action for live connection test
            add_action('wp_ajax_blupal_c2c_test_connection', array($this, 'ajax_test_connection'));

            // Webhook and Callback listener: /?wc-api=wc_blupal_c2c
            add_action('woocommerce_api_wc_blupal_c2c', array($this, 'handle_callback'));

            // Enqueue admin assets on our settings page
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        }

        /**
         * Enqueue admin stylesheets
         */
        public function enqueue_admin_assets() {
            if (isset($_GET['section']) && $_GET['section'] === $this->id) {
                wp_enqueue_style(
                    'blupal-c2c-admin',
                    BLUPAL_C2C_URL . 'assets/css/admin.css',
                    array(),
                    BLUPAL_C2C_VERSION
                );
            }
        }

        /**
         * AJAX handler for live connection test from settings page
         */
        public function ajax_test_connection() {
            check_ajax_referer('blupal_c2c_test_nonce', 'security');

            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(array('message' => __('دسترسی غیرمجاز. تنها مدیران فروشگاه امکان بررسی اتصال را دارند.', 'wc-blupal-c2c')));
            }

            $server_url = isset($_POST['server_url']) ? esc_url_raw(trim($_POST['server_url'])) : $this->server_url;
            $api_key    = isset($_POST['api_key']) ? sanitize_text_field(trim($_POST['api_key'])) : $this->api_key;

            if (empty($server_url)) {
                wp_send_json_error(array('message' => __('لطفاً ابتدا آدرس سرور (API Base URL) را در کادر تنظیمات وارد فرمایید.', 'wc-blupal-c2c')));
            }

            if (empty($api_key)) {
                wp_send_json_error(array('message' => __('لطفاً ابتدا کلید وب‌سرویس اختصاصی (API Key) را در کادر تنظیمات وارد فرمایید.', 'wc-blupal-c2c')));
            }

            $test_api = new Blupal_C2C_API($server_url, $api_key);
            $result   = $test_api->test_connection();

            if (isset($result['success']) && $result['success']) {
                wp_send_json_success($result);
            } else {
                wp_send_json_error($result);
            }
        }

        /**
         * Admin settings form fields
         */
        public function init_form_fields() {
            $site_host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field($_SERVER['HTTP_HOST']) : '';
            $clean_host = preg_replace('/^www\./i', '', $site_host);

            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('فعال‌سازی درگاه', 'wc-blupal-c2c'),
                    'type'    => 'checkbox',
                    'label'   => __('فعال‌سازی پرداخت کارت به کارت هوشمند در برگه تسویه حساب', 'wc-blupal-c2c'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __('عنوان درگاه در برگه تسویه حساب', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => __('عنوانی که خریدار در مرحله پرداخت مشاهده می‌کند.', 'wc-blupal-c2c'),
                    'default'     => __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'),
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => __('توضیحات درگاه برای مشتری', 'wc-blupal-c2c'),
                    'type'        => 'textarea',
                    'description' => __('توضیحاتی که پس از انتخاب این گزینه در صفحه پرداخت نمایش داده می‌شود.', 'wc-blupal-c2c'),
                    'default'     => __('انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.', 'wc-blupal-c2c'),
                ),
                'server_url' => array(
                    'title'       => __('آدرس وب‌سرویس / سرور پرداخت (API Base URL)', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => sprintf(
                        __('آدرس سرور یا دامنه سامانه پرداخت بلوپال بدون اسلش پایانی. پیش‌فرض: <strong dir="ltr">%s</strong>', 'wc-blupal-c2c'),
                        esc_html('http://localhost:3000')
                    ),
                    'default'     => defined('BLUPAL_C2C_DEFAULT_SERVER') ? BLUPAL_C2C_DEFAULT_SERVER : 'http://localhost:3000',
                    'placeholder' => 'http://localhost:3000',
                ),
                'api_key' => array(
                    'title'       => __('کلید اختصاصی اتصال (API Key)', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => sprintf(
                        __('کلید وب‌سرویس اختصاصی صادر شده در پنل کاربری شما. دامنه این سایت: <strong dir="ltr">%s</strong> (حتماً در پنل درگاه ثبت شود).', 'wc-blupal-c2c'),
                        esc_html($clean_host)
                    ),
                    'default'     => defined('BLUPAL_C2C_DEFAULT_API_KEY') ? BLUPAL_C2C_DEFAULT_API_KEY : '',
                    'placeholder' => 'Rakhsh_Pay_...',
                ),
            );
        }

        /**
         * Render admin options page with Live Test Connection Tool
         */
        public function admin_options() {
            $site_host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field($_SERVER['HTTP_HOST']) : '';
            $clean_host = preg_replace('/^www\./i', '', $site_host);
            $test_nonce = wp_create_nonce('blupal_c2c_test_nonce');
            ?>
            <h2><?php echo esc_html($this->method_title); ?></h2>

            <!-- Live Test Connection Box -->
            <div class="blupal-c2c-test-box">
                <div class="blupal-test-header">
                    <div class="blupal-test-title">
                        <span class="blupal-test-icon">⚡</span>
                        <div>
                            <strong>ابزار تست زنده اتصال و عیب‌یابی وب‌سرویس</strong>
                            <p>با کلیک روی دکمه زیر، ارتباط زنده با سرور و صحت کلید API سایت شما بررسی و نتیجه آنی گزارش می‌شود.</p>
                        </div>
                    </div>
                    <button type="button" id="blupal-btn-test-connection" class="button button-primary blupal-btn-test">
                        <span class="blupal-btn-text">بررسی و تست اتصال به سرور</span>
                        <span class="blupal-spinner" style="display: none;"></span>
                    </button>
                </div>

                <div id="blupal-test-result" class="blupal-test-result" style="display: none;"></div>
            </div>

            <div class="blupal-c2c-banner">
                <div class="blupal-c2c-banner-header">
                    <span class="blupal-badge">نسخه <?php echo esc_html(BLUPAL_C2C_VERSION); ?></span>
                    <h3>🛡️ راهنمای اتصال و امنیت دامنه</h3>
                </div>
                <div class="blupal-c2c-banner-body">
                    <p>۱. کلید API اختصاصی خود را از پنل کاربری کپی کرده و در فیلد زیر قرار دهید.</p>
                    <p>۲. دامنه مجاز در پنل کاربری شما باید برابر با <code dir="ltr"><?php echo esc_html($clean_host); ?></code> تنظیم شده باشد.</p>
                    <p class="blupal-c2c-ok">✓ نیازی به وارد کردن شماره کارت در سایت نیست؛ اطلاعات کارت و تایید واریز به صورت خودکار از سرور دریافت می‌شود.</p>
                </div>
            </div>

            <table class="form-table">
                <?php $this->generate_settings_html(); ?>
            </table>

            <script type="text/javascript">
            (function($) {
                $(document).ready(function() {
                    function renderSuccessResult(data, $resultBox) {
                        var details = data.details || {};
                        var latency = data.latency_ms ? data.latency_ms + ' میلی‌ثانیه' : 'آنی';

                        var html = '<div class="blupal-alert blupal-alert-success">';
                        html += '<div class="blupal-alert-head">✅ <strong>اتصال به سرور کاملاً برقرار و تایید شد!</strong> <span class="blupal-latency">پینگ سرور: ' + latency + '</span></div>';
                        html += '<p class="blupal-alert-msg">' + (data.message || 'ارتباط با سرور پرداخت با موفقیت برقرار شد.') + '</p>';

                        html += '<div class="blupal-details-grid">';
                        if (details.gateway_title) {
                            html += '<div class="blupal-grid-item"><span>نام درگاه در سامانه:</span> <strong>' + details.gateway_title + '</strong></div>';
                        }
                        if (details.card_holder) {
                            html += '<div class="blupal-grid-item"><span>وضعیت کارت پذیرنده:</span> <strong style="color:#059669;">' + details.card_holder + '</strong></div>';
                        }
                        if (details.authorized_domain) {
                            html += '<div class="blupal-grid-item"><span>دامنه مجاز درگاه:</span> <code dir="ltr">' + details.authorized_domain + '</code></div>';
                        }
                        if (details.server_url) {
                            html += '<div class="blupal-grid-item"><span>آدرس سرور پاسخ‌دهنده:</span> <code dir="ltr">' + details.server_url + '</code></div>';
                        }
                        html += '</div>';
                        html += '</div>';

                        $resultBox.html(html).slideDown(200);
                    }

                    function renderErrorResult(err, $resultBox, note) {
                        var errMsg = (err && err.message) ? err.message : 'عدم امکان برقراری ارتباط با وب‌سرویس.';
                        var latency = (err && err.latency_ms) ? ' (زمان پاسخ: ' + err.latency_ms + 'ms)' : '';

                        var html = '<div class="blupal-alert blupal-alert-error">';
                        html += '<div class="blupal-alert-head">❌ <strong>خطا در بررسی ارتباط:</strong> ' + latency + '</div>';
                        html += '<p class="blupal-alert-msg">' + errMsg + '</p>';
                        if (note) {
                            html += '<div class="blupal-troubleshoot-hint">💡 ' + note + '</div>';
                        } else {
                            html += '<div class="blupal-troubleshoot-hint">💡 <strong>راهنما:</strong> لطفاً آدرس سرور و کلید API را مجدداً بررسی کنید و در پایین صفحه روی «ذخیره تغییرات» کلیک نمایید.</div>';
                        }
                        html += '</div>';

                        $resultBox.html(html).slideDown(200);
                    }

                    $('#blupal-btn-test-connection').on('click', function(e) {
                        e.preventDefault();
                        var $btn = $(this);
                        var $spinner = $btn.find('.blupal-spinner');
                        var $btnText = $btn.find('.blupal-btn-text');
                        var $resultBox = $('#blupal-test-result');

                        var serverUrl = ($('#woocommerce_blupal_c2c_server_url').val() || '<?php echo esc_js($this->server_url); ?>').trim().replace(/\/+$/, '');
                        var apiKey = ($('#woocommerce_blupal_c2c_api_key').val() || '<?php echo esc_js($this->api_key); ?>').trim();
                        var ajaxUrl = (typeof ajaxurl !== 'undefined') ? ajaxurl : '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';

                        if (!serverUrl) {
                            renderErrorResult({ message: 'لطفاً ابتدا آدرس سرور (API Base URL) را در کادر تنظیمات زیر وارد نمایید.' }, $resultBox);
                            return;
                        }

                        $btn.prop('disabled', true);
                        $spinner.show();
                        $btnText.text('در حال برقراری ارتباط با سرور...');
                        $resultBox.slideUp(150);

                        // 1. First attempt: Standard WordPress backend AJAX
                        $.ajax({
                            url: ajaxUrl,
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                action: 'blupal_c2c_test_connection',
                                security: '<?php echo esc_js($test_nonce); ?>',
                                server_url: serverUrl,
                                api_key: apiKey
                            },
                            success: function(response) {
                                $btn.prop('disabled', false);
                                $spinner.hide();
                                $btnText.text('بررسی مجدد اتصال به سرور');

                                if (response && response.success && response.data) {
                                    renderSuccessResult(response.data, $resultBox);
                                } else {
                                    var err = (response && response.data) ? response.data : { message: 'پاسخ ناموفق از سرور' };
                                    renderErrorResult(err, $resultBox);
                                }
                            },
                            error: function(xhr, status, error) {
                                // 2. Fallback: Direct browser fetch to server test endpoint if WP AJAX had issue
                                var directEndpoint = serverUrl + '/api/v1/woocommerce/test-connection';
                                var startTime = Date.now();

                                fetch(directEndpoint, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json',
                                        'X-WP-API-KEY': apiKey
                                    },
                                    body: JSON.stringify({
                                        api_key: apiKey,
                                        site_url: window.location.origin,
                                        domain: window.location.hostname
                                    })
                                })
                                .then(function(res) { return res.json(); })
                                .then(function(directData) {
                                    $btn.prop('disabled', false);
                                    $spinner.hide();
                                    $btnText.text('بررسی مجدد اتصال به سرور');
                                    directData.latency_ms = Date.now() - startTime;

                                    if (directData && directData.success) {
                                        renderSuccessResult(directData, $resultBox);
                                    } else {
                                        renderErrorResult(directData, $resultBox);
                                    }
                                })
                                .catch(function(fetchErr) {
                                    $btn.prop('disabled', false);
                                    $spinner.hide();
                                    $btnText.text('تلاش مجدد برای تست اتصال');

                                    var detailedMsg = 'عدم دسترسی به سرور پرداخت. لطفا مطمئن شوید آدرس سرور به صورت کامل و با پیشوند https:// وارد شده است.';
                                    if (xhr && xhr.status === 403) {
                                        detailedMsg = 'دسترسی غیرمجاز وردپرس (کد ۴۰۳). لطفاً صفحه را رفرش فرمایید.';
                                    }
                                    renderErrorResult({ message: detailedMsg }, $resultBox, 'آدرس سرور جاری: <code>' + serverUrl + '</code>');
                                });
                            }
                        });
                    });
                });
            })(jQuery);
            </script>
            <?php
        }

        /**
         * Process payment and redirect customer to payment page
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                wc_add_notice(__('سفارش مورد نظر یافت نشد.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            if (empty($this->api_key)) {
                wc_add_notice(__('کلید درگاه کارت به کارت در تنظیمات ووکامرس پیکربندی نشده است.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            // Convert currency to Tomans
            $currency = get_woocommerce_currency();
            $order_total = floatval($order->get_total());
            $amount_in_tomans = $order_total;
            $curr_upper = strtoupper(trim($currency));

            if (in_array($curr_upper, array('IRR', 'RIAL', 'RIALS', 'IR_RIAL', 'IRR_CURRENCY'))) {
                $amount_in_tomans = $order_total / 10;
            } elseif (in_array($curr_upper, array('IRHR', 'THOUSAND_TOMAN', 'HEZAR_TOMAN'))) {
                $amount_in_tomans = $order_total * 1000;
            }

            $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            if (empty($customer_name)) {
                $customer_name = 'مشتری سفارش #' . $order_id;
            }

            $customer_data = array(
                'name'  => $customer_name,
                'phone' => $order->get_billing_phone(),
                'email' => $order->get_billing_email(),
            );

            $callback_url = add_query_arg(array('wc-api' => 'wc_blupal_c2c', 'order_id' => $order_id), home_url('/'));

            // Call API
            $result = $this->api->create_order($order_id, $amount_in_tomans, $currency, $customer_data, $callback_url);

            if (!$result || !isset($result['success']) || !$result['success']) {
                $msg = isset($result['message']) ? $result['message'] : __('خطا در صدور فاکتور پرداخت.', 'wc-blupal-c2c');
                wc_add_notice($msg, 'error');
                return array('result' => 'failure');
            }

            // Save invoice id into order meta
            if (!empty($result['invoice_id'])) {
                $order->update_meta_data('_blupal_c2c_invoice_id', sanitize_text_field($result['invoice_id']));
                $order->save();
            }

            // Redirect customer to secure payment page
            return array(
                'result'   => 'success',
                'redirect' => $result['payment_url'],
            );
        }

        /**
         * Check if payment gateway is available at checkout
         */
        public function is_available() {
            $enabled = $this->get_option('enabled', 'yes');
            if ($enabled === 'no' || $enabled === '0' || $enabled === false) {
                return false;
            }

            return true;
        }

        /**
         * Ensure gateway is valid for use regardless of store currency settings
         */
        public function is_valid_for_use() {
            return true;
        }

        /**
         * Handle return callback and webhook
         */
        public function handle_callback() {
            Blupal_C2C_Webhook::handle($this, $this->api);
        }
    }
}
