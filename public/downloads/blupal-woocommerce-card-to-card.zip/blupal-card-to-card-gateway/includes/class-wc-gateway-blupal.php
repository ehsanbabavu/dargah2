<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WC_Gateway_Blupal_C2C')) {
    class WC_Gateway_Blupal_C2C extends WC_Payment_Gateway {

        public $server_url;
        public $api_key;
        public $instructions;

        public function __construct() {
            $this->id                 = 'blupal_c2c';
            $this->icon               = BLUPAL_C2C_URL . 'assets/images/icon.svg';
            $this->has_fields         = false;
            $this->method_title       = __('پرداخت کارت به کارت هوشمند', 'wc-blupal-c2c');
            $this->method_description = __('پرداخت مستقیم به شماره کارت پذیرنده با استعلام خودکار و آنی واریزی از طریق سامانه شتاب.', 'wc-blupal-c2c');

            // Load settings
            $this->init_form_fields();
            $this->init_settings();

            // Define user configurable settings
            $this->title        = $this->get_option('title', __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'));
            $this->description  = $this->get_option('description', __('انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.', 'wc-blupal-c2c'));
            $this->enabled      = $this->get_option('enabled', 'yes');
            $this->server_url   = $this->get_option('server_url', BLUPAL_C2C_DEFAULT_SERVER);
            $this->api_key      = $this->get_option('api_key', BLUPAL_C2C_DEFAULT_API_KEY);

            // Hook into admin save
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            // AJAX action for live connection test
            add_action('wp_ajax_blupal_c2c_test_connection', array($this, 'ajax_test_connection'));

            // Webhook and Callback listener: /?wc-api=wc_blupal_c2c
            add_action('woocommerce_api_wc_blupal_c2c', array($this, 'handle_callback'));

            // Show thank you page notes
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
            
            // Show email notes
            add_action('woocommerce_email_before_order_table', array($this, 'email_instructions'), 10, 3);
        }

        /**
         * AJAX handler for live connection test from settings page
         */
        public function ajax_test_connection() {
            check_ajax_referer('blupal_c2c_test_nonce', 'security');

            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(array('message' => __('دسترسی غیرمجاز. تنها مدیران فروشگاه امکان بررسی اتصال را دارند.', 'wc-blupal-c2c')));
            }

            $server_url = isset($_POST['server_url']) ? esc_url_raw(trim($_POST['server_url'])) : $this->server_url;
            $api_key    = isset($_POST['api_key']) ? sanitize_text_field(trim($_POST['api_key'])) : $this->api_key;

            if (empty($server_url)) {
                wp_send_json_error(array('message' => __('لطفاً ابتدا آدرس سرور (API Base URL) را در کادر تنظیمات وارد فرمایید.', 'wc-blupal-c2c')));
            }

            if (empty($api_key)) {
                wp_send_json_error(array('message' => __('لطفاً ابتدا کلید وب‌سرویس اختصاصی (API Key) را در کادر تنظیمات وارد فرمایید.', 'wc-blupal-c2c')));
            }

            $test_api = new Blupal_C2C_API($server_url, $api_key);
            $result   = $test_api->test_connection();

            if (isset($result['success']) && $result['success']) {
                wp_send_json_success($result);
            } else {
                wp_send_json_error($result);
            }
        }

        /**
         * Admin settings form fields
         */
        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('فعال‌سازی درگاه', 'wc-blupal-c2c'),
                    'type'    => 'checkbox',
                    'label'   => __('فعال‌سازی پرداخت کارت به کارت هوشمند در برگه تسویه حساب', 'wc-blupal-c2c'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __('عنوان درگاه در برگه تسویه حساب', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => __('عنوانی که خریدار در مرحله پرداخت مشاهده می‌کند.', 'wc-blupal-c2c'),
                    'default'     => __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'),
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => __('توضیحات درگاه برای مشتری', 'wc-blupal-c2c'),
                    'type'        => 'textarea',
                    'description' => __('توضیحات تکمیلی که پس از انتخاب این درگاه به خریدار نمایش داده می‌شود.', 'wc-blupal-c2c'),
                    'default'     => __('انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.', 'wc-blupal-c2c'),
                    'desc_tip'    => true,
                ),
                'server_url' => array(
                    'title'       => __('آدرس وب‌سرویس / سرور پرداخت (API Base URL)', 'wc-blupal-c2c'),
                    'type'        => 'text',
                    'description' => __('دامنه یا آدرس کامل سرور صدور فاکتور و استعلام واریزی.', 'wc-blupal-c2c'),
                    'default'     => BLUPAL_C2C_DEFAULT_SERVER,
                    'desc_tip'    => true,
                ),
                'api_key' => array(
                    'title'       => __('کلید اختصاصی اتصال (API Key)', 'wc-blupal-c2c'),
                    'type'        => 'password',
                    'description' => __('کلید اختصاصی احراز هویت وب‌سرویس درگاه کارت به کارت شما.', 'wc-blupal-c2c'),
                    'default'     => BLUPAL_C2C_DEFAULT_API_KEY,
                    'desc_tip'    => true,
                ),
            );
        }

        /**
         * Custom Admin Options Page Output
         */
        public function admin_options() {
            ?>
            <div class="blupal-c2c-admin-wrapper">
                <div class="blupal-c2c-admin-header">
                    <div class="blupal-c2c-badge">نسخه ۱.۱.۰</div>
                    <h2>💳 تنظیمات درگاه پرداخت کارت به کارت هوشمند (بلوپال)</h2>
                    <p>درگاه اختصاصی انتقال وجه کارت به کارت با الگوریتم هوشمند پردازش و تایید خودکار واریزی‌های شتابی.</p>
                </div>

                <div class="blupal-c2c-status-card">
                    <div class="blupal-c2c-status-info">
                        <div class="blupal-c2c-status-icon">⚡</div>
                        <div>
                            <h4>وضعیت اتصال به سامانه پرداخت</h4>
                            <p id="blupal-connection-msg">برای سنجش برقرار بودن ارتباط با سرور صدور فاکتور، روی دکمه برقراری آزمایشی اتصال کلیک کنید.</p>
                        </div>
                    </div>
                    <button type="button" id="blupal-test-btn" class="button button-secondary blupal-c2c-btn-test">
                        🔍 بررسی و تست آنلاین اتصال
                    </button>
                </div>

                <table class="form-table">
                    <?php $this->generate_settings_html(); ?>
                </table>
            </div>

            <script>
            jQuery(document).ready(function($) {
                $('#blupal-test-btn').on('click', function(e) {
                    e.preventDefault();
                    var $btn = $(this);
                    var $msg = $('#blupal-connection-msg');
                    
                    var serverUrl = $('#woocommerce_blupal_c2c_server_url').val();
                    var apiKey = $('#woocommerce_blupal_c2c_api_key').val();

                    $btn.prop('disabled', true).text('⏳ در حال برقراری ارتباط...');
                    $msg.css('color', '#6b7280').text('در حال ارسال درخواست تست به سرور...');

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            action: 'blupal_c2c_test_connection',
                            security: '<?php echo wp_create_nonce("blupal_c2c_test_nonce"); ?>',
                            server_url: serverUrl,
                            api_key: apiKey
                        },
                        success: function(response) {
                            $btn.prop('disabled', false).text('🔍 بررسی و تست آنلاین اتصال');
                            if (response.success) {
                                $msg.css('color', '#059669').html('✅ <strong>اتصال موفقیت‌آمیز بود!</strong> ' + (response.data.message || 'سرور آماده پذیرش تراکنش‌هاست.'));
                            } else {
                                var errorText = response.data && response.data.message ? response.data.message : 'خطا در برقراری ارتباط';
                                $msg.css('color', '#dc2626').html('❌ <strong>خطا در اتصال:</strong> ' + errorText);
                            }
                        },
                        error: function(xhr, status, error) {
                            $btn.prop('disabled', false).text('🔍 بررسی و تست آنلاین اتصال');
                            $msg.css('color', '#dc2626').html('❌ <strong>خطای شبکه:</strong> عدم دریافت پاسخ صحیح از سرور (' + status + ')');
                        }
                    });
                });
            });
            </script>
            <?php
        }

        /**
         * Process Checkout Payment Redirect
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);

            if (!$order) {
                wc_add_notice(__('سفارش مورد نظر یافت نشد.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            if (empty($this->server_url) || empty($this->api_key)) {
                wc_add_notice(__('کلید درگاه کارت به کارت در تنظیمات ووکامرس پیکربندی نشده است.', 'wc-blupal-c2c'), 'error');
                return array('result' => 'failure');
            }

            $api = new Blupal_C2C_API($this->server_url, $this->api_key);

            // Get amount in Tomans (convert from Rials if store currency is IRR)
            $amount = $order->get_total();
            $currency = get_woocommerce_currency();
            
            if ($currency === 'IRR') {
                $amount_toman = round($amount / 10);
            } else {
                $amount_toman = round($amount);
            }

            // Customer details
            $payer_name  = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            $payer_phone = $order->get_billing_phone();
            $payer_email = $order->get_billing_email();

            // Callback URL upon user return
            $callback_url = add_query_arg(array(
                'wc-api'   => 'wc_blupal_c2c',
                'order_id' => $order_id
            ), home_url('/'));

            $result = $api->create_order(array(
                'order_id'     => (string)$order_id,
                'amount_toman' => $amount_toman,
                'payer_name'   => $payer_name,
                'payer_phone'  => $payer_phone,
                'payer_email'  => $payer_email,
                'callback_url' => $callback_url,
                'description'  => sprintf('پرداخت سفارش شماره %s در فروشگاه', $order->get_order_number()),
            ));

            if (!$result || !isset($result['success']) || !$result['success']) {
                $error_msg = isset($result['message']) ? $result['message'] : __('خطا در صدور فاکتور پرداخت.', 'wc-blupal-c2c');
                wc_add_notice($error_msg, 'error');
                return array('result' => 'failure');
            }

            // Save Invoice ID in order meta
            if (!empty($result['invoice_id'])) {
                $order->update_meta_data('_blupal_c2c_invoice_id', sanitize_text_field($result['invoice_id']));
                $order->save();
            }

            // Redirect customer to secure payment page
            return array(
                'result'   => 'success',
                'redirect' => $result['payment_url']
            );
        }

        /**
         * Check if payment gateway is available at checkout
         */
        public function is_available() {
            $enabled = $this->get_option('enabled', 'yes');
            if ($enabled === 'no' || $enabled === '0' || $enabled === false) {
                return false;
            }

            return true;
        }

        /**
         * Ensure gateway is valid for use regardless of store currency settings
         */
        public function is_valid_for_use() {
            return true;
        }

        /**
         * Handle callback & Webhook verification from payment server
         */
        public function handle_callback() {
            $api = new Blupal_C2C_API($this->server_url, $this->api_key);
            Blupal_C2C_Webhook::handle($this, $api);
        }

        /**
         * Custom instructions on Thank You page
         */
        public function thankyou_page($order_id) {
            $order = wc_get_order($order_id);
            if ($order && $order->is_paid()) {
                echo '<div class="woocommerce-message" style="margin-top:20px;">' . esc_html__('پرداخت شما با موفقیت تایید شد. سفارش شما در حال پردازش می‌باشد.', 'wc-blupal-c2c') . '</div>';
            }
        }

        /**
         * Custom instructions in email
         */
        public function email_instructions($order, $sent_to_admin, $plain_text = false) {
            if ($order->get_payment_method() === $this->id && $order->is_paid()) {
                echo '<p><strong>' . esc_html__('پرداخت کارت به کارت هوشمند:', 'wc-blupal-c2c') . '</strong> ' . esc_html__('تراکنش با موفقیت تایید و در سیستم ثبت شد.', 'wc-blupal-c2c') . '</p>';
            }
        }
    }
}
