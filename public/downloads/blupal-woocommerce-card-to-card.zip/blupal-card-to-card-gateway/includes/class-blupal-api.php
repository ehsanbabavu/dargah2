<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Blupal_C2C_API')) {
    class Blupal_C2C_API {
        private $server_url;
        private $api_key;

        public function __construct($server_url, $api_key) {
            $this->server_url = rtrim($server_url, '/');
            $this->api_key    = trim($api_key);
        }

        /**
         * Create order on server and get payment URL
         */
        public function create_order($order_id, $amount, $currency, $customer_data, $callback_url) {
            $site_url = get_site_url();
            $endpoint = $this->server_url . '/api/v1/woocommerce/create-order';

            $payload = array(
                'api_key'        => $this->api_key,
                'order_id'       => (string) $order_id,
                'amount'         => (float) $amount,
                'currency'       => $currency,
                'customer_name'  => $customer_data['name'],
                'customer_phone' => $customer_data['phone'],
                'customer_email' => $customer_data['email'],
                'site_url'       => $site_url,
                'callback_url'   => $callback_url,
                'description'    => sprintf('سفارش #%s در %s', $order_id, get_bloginfo('name')),
            );

            $response = wp_remote_post($endpoint, array(
                'method'      => 'POST',
                'timeout'     => 25,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                    'X-WP-API-KEY' => $this->api_key,
                    'Origin'       => $site_url,
                    'Referer'      => $site_url,
                ),
                'body'        => json_encode($payload),
            ));

            if (is_wp_error($response)) {
                return array('success' => false, 'message' => $response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $code = wp_remote_retrieve_response_code($response);

            if ($code !== 200 || !isset($data['success']) || !$data['success']) {
                $msg = isset($data['message']) ? $data['message'] : 'خطا در ارتباط با سرور صدور فاکتور';
                return array('success' => false, 'message' => $msg);
            }

            return $data;
        }

        /**
         * Verify payment status of an invoice
         */
        public function verify_order($order_id, $invoice_id) {
            $site_url = get_site_url();
            $verify_endpoint = add_query_arg(array(
                'order_id'   => $order_id,
                'invoice_id' => $invoice_id,
            ), $this->server_url . '/api/v1/woocommerce/verify');

            $response = wp_remote_get($verify_endpoint, array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'       => 'application/json',
                    'X-WP-API-KEY' => $this->api_key,
                    'Origin'       => $site_url,
                    'Referer'      => $site_url,
                ),
            ));

            if (is_wp_error($response)) {
                return array('success' => false, 'message' => $response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            return json_decode($body, true);
        }

        /**
         * Test live connection with the payment gateway server and validate API key
         */
        public function test_connection() {
            $site_url = get_site_url();
            $endpoint = $this->server_url . '/api/v1/woocommerce/test-connection';

            $start_time = microtime(true);

            $response = wp_remote_post($endpoint, array(
                'method'      => 'POST',
                'timeout'     => 15,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                    'X-WP-API-KEY' => $this->api_key,
                    'Origin'       => $site_url,
                    'Referer'      => $site_url,
                ),
                'body'        => json_encode(array(
                    'api_key'    => $this->api_key,
                    'site_url'   => $site_url,
                    'domain'     => preg_replace('/^https?:///i', '', $site_url),
                    'wp_version' => get_bloginfo('version'),
                    'wc_version' => defined('WC_VERSION') ? WC_VERSION : 'unknown',
                )),
            ));

            $latency_ms = round((microtime(true) - $start_time) * 1000);

            if (is_wp_error($response)) {
                return array(
                    'success'    => false,
                    'status'     => 'network_error',
                    'message'    => 'عدم امکان برقراری ارتباط با سرور: ' . $response->get_error_message(),
                    'latency_ms' => $latency_ms,
                );
            }

            $body = wp_remote_retrieve_body($response);
            $code = wp_remote_retrieve_response_code($response);
            $data = json_decode($body, true);

            if (!is_array($data)) {
                return array(
                    'success'    => false,
                    'status'     => 'invalid_response',
                    'message'    => sprintf('پاسخ نامعتبر از سرور (کد وضعیت: %s). بررسی فرمایید آدرس سرور بدون اسلش پایانی ثبت شده باشد.', $code),
                    'latency_ms' => $latency_ms,
                    'raw_body'   => substr($body, 0, 300),
                );
            }

            $data['latency_ms'] = $latency_ms;
            $data['http_code']  = $code;
            return $data;
        }
    }
}
