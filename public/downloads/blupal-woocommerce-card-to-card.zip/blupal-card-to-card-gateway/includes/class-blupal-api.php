<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Blupal_C2C_API')) {
    class Blupal_C2C_API {

        private $server_url;
        private $api_key;

        public function __construct($server_url, $api_key) {
            $this->server_url = rtrim(trim($server_url), '/');
            $this->api_key    = trim($api_key);
        }

        /**
         * Create order / invoice on payment server
         */
        public function create_order($data) {
            $endpoint = $this->server_url . '/api/blupal/create-gateway-invoice';

            $payload = array(
                'api_key'      => $this->api_key,
                'order_id'     => $data['order_id'],
                'amount_toman' => (int)$data['amount_toman'],
                'payer_name'   => $data['payer_name'],
                'payer_phone'  => $data['payer_phone'],
                'payer_email'  => $data['payer_email'],
                'callback_url' => $data['callback_url'],
                'description'  => $data['description'],
            );

            $response = wp_remote_post($endpoint, array(
                'method'      => 'POST',
                'timeout'     => 25,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ),
                'body'        => json_encode($payload),
                'sslverify'   => false,
            ));

            if (is_wp_error($response)) {
                return array(
                    'success' => false,
                    'message' => 'خطای ارتباط با سرور: ' . $response->get_error_message()
                );
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $code = wp_remote_retrieve_response_code($response);

            if ($code !== 200 || !isset($data['success']) || !$data['success']) {
                $msg = isset($data['message']) ? $data['message'] : 'خطا در صدور فاکتور پرداخت';
                return array('success' => false, 'message' => $msg);
            }

            return $data;
        }

        /**
         * Verify payment status with payment server
         */
        public function verify_order($order_id, $invoice_id) {
            $endpoint = $this->server_url . '/api/blupal/verify-gateway-invoice';

            $payload = array(
                'api_key'    => $this->api_key,
                'order_id'   => (string)$order_id,
                'invoice_id' => (string)$invoice_id,
            );

            $response = wp_remote_post($endpoint, array(
                'method'      => 'POST',
                'timeout'     => 20,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ),
                'body'        => json_encode($payload),
                'sslverify'   => false,
            ));

            if (is_wp_error($response)) {
                return array('success' => false, 'message' => $response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            return json_decode($body, true);
        }

        /**
         * Test live connection to payment server
         */
        public function test_connection() {
            $endpoint = $this->server_url . '/api/blupal/test-connection';
            $site_url = home_url('/');

            $response = wp_remote_post($endpoint, array(
                'method'      => 'POST',
                'timeout'     => 15,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ),
                'body'        => json_encode(array(
                    'api_key'    => $this->api_key,
                    'site_url'   => $site_url,
                    'domain'     => preg_replace('/^https?:///i', '', $site_url),
                    'wp_version' => get_bloginfo('version'),
                    'wc_version' => defined('WC_VERSION') ? WC_VERSION : 'unknown',
                )),
                'sslverify'   => false,
            ));

            if (is_wp_error($response)) {
                return array('success' => false, 'message' => $response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (is_array($data)) {
                return $data;
            }

            return array(
                'success' => false,
                'message' => 'پاسخ دریافتی فرمت JSON معتبر ندارد. وضعیت کد HTTP: ' . wp_remote_retrieve_response_code($response)
            );
        }
    }
}
