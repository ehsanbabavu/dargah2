<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Blupal_C2C_Webhook')) {
    class Blupal_C2C_Webhook {
        public static function handle($gateway, $api) {
            $request_method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';

            // Read parameters from GET/POST and JSON body safely
            $order_id   = isset($_REQUEST['order_id']) ? sanitize_text_field(wp_unslash($_REQUEST['order_id'])) : '';
            $invoice_id = isset($_REQUEST['invoice_id']) ? sanitize_text_field(wp_unslash($_REQUEST['invoice_id'])) : '';

            $raw_input = file_get_contents('php://input');
            if (!empty($raw_input)) {
                $json = json_decode($raw_input, true);
                if (is_array($json)) {
                    if (empty($order_id) && isset($json['order_id'])) {
                        $order_id = sanitize_text_field(wp_unslash($json['order_id']));
                    }
                    if (empty($invoice_id) && isset($json['invoice_id'])) {
                        $invoice_id = sanitize_text_field(wp_unslash($json['invoice_id']));
                    }
                }
            }

            if (empty($order_id)) {
                if ('POST' === $request_method) {
                    wp_send_json_error(array('message' => 'شناسه سفارش نامعتبر است.'), 400);
                    exit;
                }
                wp_die(__('شناسه سفارش نامعتبر است.', 'wc-blupal-c2c'), __('خطا در پرداخت', 'wc-blupal-c2c'), array('response' => 400));
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                if ('POST' === $request_method) {
                    wp_send_json_error(array('message' => 'سفارش مورد نظر یافت نشد.'), 404);
                    exit;
                }
                wp_die(__('سفارش مورد نظر یافت نشد.', 'wc-blupal-c2c'), __('خطا در پرداخت', 'wc-blupal-c2c'), array('response' => 404));
            }

            // شناسه فاکتور معتبر همیشه از متای همین سفارش خوانده می‌شود، نه از ورودی کاربر.
            $stored_invoice_id = (string) $order->get_meta('_blupal_c2c_invoice_id');

            if (empty($stored_invoice_id)) {
                if ('POST' === $request_method) {
                    wp_send_json_error(array('message' => 'فاکتور پرداختی برای این سفارش ثبت نشده است.'), 400);
                    exit;
                }
                wp_die(
                    __('فاکتور پرداختی برای این سفارش ثبت نشده است.', 'wc-blupal-c2c'),
                    __('خطا در پرداخت', 'wc-blupal-c2c'),
                    array('response' => 400)
                );
            }

            // اگر شناسه فاکتور ورودی ارسال شده، باید با فاکتور ثبت‌شده مطابقت داشته باشد.
            if (!empty($invoice_id) && !hash_equals($stored_invoice_id, (string) $invoice_id)) {
                if ('POST' === $request_method) {
                    wp_send_json_error(array('message' => 'شناسه فاکتور نامعتبر است.'), 403);
                    exit;
                }
                wp_die(
                    __('شناسه فاکتور نامعتبر است.', 'wc-blupal-c2c'),
                    __('خطا در پرداخت', 'wc-blupal-c2c'),
                    array('response' => 403)
                );
            }

            // از این پس فقط به شناسه فاکتور ذخیره‌شده اعتماد کن.
            $invoice_id = $stored_invoice_id;

            // If already paid, exit gracefully
            if ($order->is_paid()) {
                if ('POST' === $request_method) {
                    wp_send_json_success(array('order_id' => $order_id, 'status' => 'already_paid'));
                    exit;
                }
                if (function_exists('WC') && WC()->cart) {
                    WC()->cart->empty_cart();
                }
                wp_safe_redirect($gateway->get_return_url($order));
                exit;
            }

            // Verify with API
            $data = $api->verify_order($order_id, $invoice_id);

            if (!$data || !isset($data['success']) || !$data['success']) {
                $order->add_order_note(__('خطا در استعلام وضعیت پرداخت از سرور کارت به کارت: ', 'wc-blupal-c2c') . (isset($data['message']) ? $data['message'] : 'عدم پاسخگویی'));
                if ('POST' === $request_method) {
                    wp_send_json_error(array('message' => 'خطا در ارتباط با سرور تایید'));
                    exit;
                }
                wc_add_notice(__('خطا در اعتبارسنجی پرداخت. در صورت کسر وجه با پشتیبانی تماس بگیرید.', 'wc-blupal-c2c'), 'error');
                wp_safe_redirect(wc_get_checkout_url());
                exit;
            }

            $is_paid = isset($data['status']) && $data['status'] === 'paid';

            if ($is_paid) {
                $tracking_code = isset($data['tracking_code']) ? sanitize_text_field($data['tracking_code']) : (isset($_REQUEST['tracking_code']) ? sanitize_text_field($_REQUEST['tracking_code']) : 'تایید شده');

                if (!$order->is_paid()) {
                    $order->payment_complete($tracking_code);
                    $order->add_order_note(sprintf(
                        __('پرداخت کارت به کارت با موفقیت تایید شد. کد رهگیری شتاب: %s | شناسه فاکتور: %s', 'wc-blupal-c2c'),
                        $tracking_code,
                        $invoice_id
                    ));
                    if (!empty($data['card_last_four'])) {
                        $order->add_order_note(sprintf(__('۴ رقم آخر کارت واریزکننده: %s', 'wc-blupal-c2c'), sanitize_text_field($data['card_last_four'])));
                    }
                    // موجودی به‌صورت خودکار توسط هوک woocommerce_payment_complete کسر می‌شود.
                }

                if ('POST' === $request_method) {
                    wp_send_json_success(array('order_id' => $order_id, 'status' => 'completed'));
                    exit;
                }

                if (function_exists('WC') && WC()->cart) {
                    WC()->cart->empty_cart();
                }
                wp_safe_redirect($gateway->get_return_url($order));
                exit;
            } else {
                $order->update_status('failed', __('پرداخت کارت به کارت تایید نشد یا منقضی گردید.', 'wc-blupal-c2c'));

                if ('POST' === $request_method) {
                    wp_send_json_error(array('order_id' => $order_id, 'status' => 'failed'));
                    exit;
                }

                wc_add_notice(__('پرداخت کارت به کارت تایید نشد یا زمان واریز به پایان رسید. لطفاً مجدداً تلاش فرمایید.', 'wc-blupal-c2c'), 'error');
                wp_safe_redirect(wc_get_checkout_url());
                exit;
            }
        }
    }
}
