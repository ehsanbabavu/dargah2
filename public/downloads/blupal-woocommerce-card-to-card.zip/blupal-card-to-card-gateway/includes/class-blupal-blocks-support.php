<?php
if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!class_exists('WC_Blupal_Blocks_Support') && class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
    final class WC_Blupal_Blocks_Support extends AbstractPaymentMethodType {
        protected $name = 'blupal_c2c';

        public function initialize() {
            $this->settings = get_option('woocommerce_blupal_c2c_settings', array());
        }

        public function is_active() {
            $enabled = isset($this->settings['enabled']) ? $this->settings['enabled'] : 'yes';
            return ('no' !== $enabled && '0' !== $enabled && false !== $enabled);
        }

        public function get_payment_method_script_handles() {
            wp_register_script(
                'blupal-c2c-blocks-integration',
                BLUPAL_C2C_URL . 'assets/js/blocks.js',
                array(),
                BLUPAL_C2C_VERSION,
                true
            );
            return array('blupal-c2c-blocks-integration');
        }

        public function get_payment_method_data() {
            return array(
                'title'       => isset($this->settings['title']) && !empty($this->settings['title']) ? $this->settings['title'] : __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'),
                'description' => isset($this->settings['description']) && !empty($this->settings['description']) ? $this->settings['description'] : __('انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.', 'wc-blupal-c2c'),
                'icon'        => BLUPAL_C2C_URL . 'assets/images/icon.svg',
                'supports'    => array('products'),
                'ariaLabel'   => __('پرداخت کارت به کارت هوشمند (تایید آنی)', 'wc-blupal-c2c'),
            );
        }
    }
}
