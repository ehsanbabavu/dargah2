<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!defined('ABSPATH')) {
    exit;
}

final class WC_Blupal_Blocks_Support extends AbstractPaymentMethodType {

    protected $name = 'blupal_c2c';

    public function initialize() {
        $this->settings = get_option('woocommerce_blupal_c2c_settings', array());
    }

    public function is_active() {
        return filter_var($this->get_setting('enabled', true), FILTER_VALIDATE_BOOLEAN);
    }

    public function get_payment_method_script_handles() {
        wp_register_script(
            'blupal-c2c-blocks-integration',
            BLUPAL_C2C_URL . 'assets/js/blocks.js',
            array(),
            BLUPAL_C2C_VERSION,
            true
        );
        return array('blupal-c2c-blocks-integration');
    }

    public function get_payment_method_data() {
        return array(
            'title'       => $this->get_setting('title', 'پرداخت کارت به کارت هوشمند (تایید آنی)'),
            'description' => $this->get_setting('description', 'انتقال وجه کارت به کارت با تایید خودکار و لحظه‌ای از شبکه شتاب.'),
            'supports'    => array('products'),
            'icon'        => BLUPAL_C2C_URL . 'assets/images/icon.svg',
        );
    }
}
